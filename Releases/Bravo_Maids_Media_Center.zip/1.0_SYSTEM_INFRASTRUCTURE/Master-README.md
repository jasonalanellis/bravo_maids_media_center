# SYSTEM INFRASTRUCTURE
This module contains system rules, folder maps, conventions, and ops SOPs.
