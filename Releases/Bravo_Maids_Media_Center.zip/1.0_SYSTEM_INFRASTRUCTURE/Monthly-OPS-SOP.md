# Monthly OPS SOP
Monthly planning.
