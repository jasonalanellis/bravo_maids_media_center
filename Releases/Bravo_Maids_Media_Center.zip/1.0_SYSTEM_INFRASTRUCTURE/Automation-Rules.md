# Automation Rules
Rules for file generation, updates, and dependencies.
