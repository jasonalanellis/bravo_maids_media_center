# Weekly OPS SOP
Weekly tasks.
